(() => {
  // src/shared/constants.js
  var PROTOCOL_VERSION = 1;
  var FRAGMENT_PREFIX = "#zotero-ablesci=";
  var PAYLOAD_TTL_MS = 30 * 60 * 1e3;
  var MAX_LENGTHS = Object.freeze({
    title: 1e3,
    doi: 300,
    author: 300,
    publicationTitle: 500,
    year: 4,
    url: 2e3,
    zoteroKey: 32,
    itemType: 64
  });

  // src/shared/metadata.js
  function normalizeText(value, maxLength) {
    if (typeof value !== "string") {
      return "";
    }
    return value.replace(/\s+/gu, " ").trim().slice(0, maxLength).trimEnd();
  }
  function normalizeDoi(value) {
    const doi = normalizeText(value, Number.MAX_SAFE_INTEGER).replace(/^doi:\s*/iu, "").replace(/^(?:https?:\/\/)?(?:dx\.)?doi\.org\//iu, "").toLowerCase().slice(0, MAX_LENGTHS.doi);
    return /^10\.\d{4,9}\/\S+$/u.test(doi) ? doi : "";
  }
  function normalizeUrl(value) {
    const candidate = normalizeText(value, MAX_LENGTHS.url);
    if (!candidate) {
      return "";
    }
    try {
      const url = new URL(candidate);
      if (url.protocol !== "http:" && url.protocol !== "https:") {
        return "";
      }
      return url.href.slice(0, MAX_LENGTHS.url);
    } catch {
      return "";
    }
  }
  function normalizeYear(value) {
    const candidate = typeof value === "string" || typeof value === "number" ? String(value) : "";
    const match = candidate.match(/(?:18|19|20|21)\d{2}/u);
    return match ? match[0].slice(0, MAX_LENGTHS.year) : "";
  }
  function normalizeMetadata(item) {
    const source = item && typeof item === "object" && !Array.isArray(item) ? item : {};
    const title = normalizeText(source.title, MAX_LENGTHS.title);
    if (!title) {
      throw new Error("TITLE_REQUIRED");
    }
    const authors = [];
    if (Array.isArray(source.authors)) {
      for (const author of source.authors) {
        const normalized = normalizeText(author, MAX_LENGTHS.author);
        if (normalized) {
          authors.push(normalized);
        }
        if (authors.length === 100) {
          break;
        }
      }
    }
    return {
      title,
      doi: normalizeDoi(source.doi),
      authors,
      publicationTitle: normalizeText(
        source.publicationTitle,
        MAX_LENGTHS.publicationTitle
      ),
      year: normalizeYear(source.year),
      url: normalizeUrl(source.url),
      zoteroKey: normalizeText(source.zoteroKey, MAX_LENGTHS.zoteroKey),
      itemType: normalizeText(source.itemType, MAX_LENGTHS.itemType)
    };
  }

  // src/shared/clipboard.js
  function formatMetadataText(item) {
    const metadata = normalizeMetadata(item);
    const lines = [`\u6807\u9898\uFF1A${metadata.title}`];
    if (metadata.doi) lines.push(`DOI\uFF1A${metadata.doi}`);
    if (metadata.authors.length) lines.push(`\u4F5C\u8005\uFF1A${metadata.authors.join("\uFF1B")}`);
    if (metadata.publicationTitle) lines.push(`\u671F\u520A\uFF1A${metadata.publicationTitle}`);
    if (metadata.year) lines.push(`\u5E74\u4EFD\uFF1A${metadata.year}`);
    if (metadata.url) lines.push(`\u5B98\u65B9\u94FE\u63A5\uFF1A${metadata.url}`);
    return lines.join("\n");
  }

  // src/shared/payload.js
  var FUTURE_TOLERANCE_MS = 5 * 60 * 1e3;
  var BASE64URL_PATTERN = /^[A-Za-z0-9_-]+$/u;
  function payloadError(code) {
    return new Error(code);
  }
  function decodeBase64Url(value) {
    if (!BASE64URL_PATTERN.test(value) || value.length % 4 === 1) {
      throw payloadError("PAYLOAD_MALFORMED");
    }
    const base64 = value.replace(/-/gu, "+").replace(/_/gu, "/");
    const padded = base64.padEnd(base64.length + (4 - base64.length % 4) % 4, "=");
    try {
      let bytes;
      if (typeof globalThis.Buffer !== "undefined") {
        bytes = globalThis.Buffer.from(padded, "base64");
      } else {
        const binary = atob(padded);
        bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
      }
      return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    } catch {
      throw payloadError("PAYLOAD_MALFORMED");
    }
  }
  function isRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }
  function decodeFragment(fragment, options = {}) {
    if (typeof fragment !== "string" || !fragment.startsWith(FRAGMENT_PREFIX)) {
      throw payloadError("PAYLOAD_PREFIX_INVALID");
    }
    let payload;
    try {
      payload = JSON.parse(decodeBase64Url(fragment.slice(FRAGMENT_PREFIX.length)));
    } catch (error) {
      if (error?.message === "PAYLOAD_MALFORMED") {
        throw error;
      }
      throw payloadError("PAYLOAD_MALFORMED");
    }
    if (!isRecord(payload)) {
      throw payloadError("PAYLOAD_MALFORMED");
    }
    if (payload.v !== PROTOCOL_VERSION) {
      throw payloadError("PAYLOAD_VERSION_UNSUPPORTED");
    }
    if (!Number.isFinite(payload.createdAt)) {
      throw payloadError("PAYLOAD_MALFORMED");
    }
    const now = options.now === void 0 ? Date.now() : options.now;
    if (!Number.isFinite(now)) {
      throw payloadError("PAYLOAD_MALFORMED");
    }
    if (payload.createdAt > now + FUTURE_TOLERANCE_MS) {
      throw payloadError("PAYLOAD_FROM_FUTURE");
    }
    if (now - payload.createdAt > PAYLOAD_TTL_MS) {
      throw payloadError("PAYLOAD_EXPIRED");
    }
    if (typeof payload.nonce !== "string" || !payload.nonce.trim()) {
      throw payloadError("PAYLOAD_NONCE_REQUIRED");
    }
    if (!isRecord(payload.item)) {
      throw payloadError("PAYLOAD_MALFORMED");
    }
    return {
      v: PROTOCOL_VERSION,
      createdAt: payload.createdAt,
      nonce: payload.nonce,
      item: normalizeMetadata(payload.item)
    };
  }

  // src/browser/fragment.js
  function consumeFragment({
    decode = decodeFragment,
    locationObject = globalThis.location,
    historyObject = globalThis.history
  } = {}) {
    const fragment = locationObject.hash;
    if (!fragment?.startsWith(FRAGMENT_PREFIX)) return null;
    try {
      return decode(fragment);
    } finally {
      historyObject.replaceState(
        historyObject.state,
        "",
        `${locationObject.pathname}${locationObject.search}`
      );
    }
  }

  // src/browser/selectors.js
  var FIELD_SELECTORS = Object.freeze({
    doi: [
      'input[name="doi"]',
      'input[id*="doi" i]',
      'input[placeholder*="DOI" i]'
    ],
    title: [
      'input[name="title"]',
      'textarea[name="title"]',
      'input[placeholder*="\u6807\u9898"]',
      'textarea[placeholder*="\u6807\u9898"]'
    ],
    authors: [
      'input[name="author"]',
      'input[name="authors"]',
      'textarea[name="authors"]',
      'input[placeholder*="\u4F5C\u8005"]'
    ],
    publicationTitle: [
      'input[name="journal"]',
      'input[name="publication"]',
      'input[placeholder*="\u671F\u520A"]'
    ],
    year: ['input[name="year"]', 'input[placeholder*="\u5E74\u4EFD"]'],
    url: [
      'input[name="url"]',
      'input[name="link"]',
      'input[placeholder*="\u7F51\u5740"]',
      'input[placeholder*="\u94FE\u63A5"]'
    ]
  });
  var QUERY_SELECTORS = Object.freeze([
    '[data-testid="doi-query"]',
    'button[name="doi-query"]',
    'button:not([type="submit"])',
    '[role="button"]',
    'button[type="button"]'
  ]);
  var QUERY_ERROR_SELECTORS = Object.freeze([
    '[data-testid="doi-error"]',
    '[role="alert"]',
    ".error-message"
  ]);

  // src/browser/dom-adapter.js
  var FIELDS = Object.keys(FIELD_SELECTORS);
  var LABEL_PATTERNS = Object.freeze({
    doi: [/doi/i],
    title: [/标题/u, /题名/u, /文献名/u, /文名/u],
    authors: [/作者/u, /著者/u, /author/i],
    publicationTitle: [/期刊/u, /刊名/u, /杂志/u, /journal/i],
    year: [/年份/u, /发表年/u, /出版年/u, /^年$/u, /year/i],
    url: [/官网/u, /链接/u, /网址/u, /\burl\b/i, /原文/u],
    otherInfo: [/其他信息/u, /补充信息/u, /备注/u]
  });
  var QUERY_CONTEXT_PATTERN = /一键求助|科研通AI|智能提取|PMID/u;
  var CONTROL_SELECTOR = 'input:not([type="hidden"]), textarea, select, [contenteditable="true"]';
  function isVisible(element) {
    for (let current = element; current; current = current.parentElement) {
      if (current.hidden || current.getAttribute("aria-hidden") === "true" || current.style?.display === "none" || current.style?.visibility === "hidden") {
        return false;
      }
    }
    return Boolean(element && element.getAttribute("type") !== "hidden");
  }
  function unique(elements) {
    return [...new Set(elements)];
  }
  function textOf(element) {
    return String(element?.textContent ?? "").replace(/\s+/gu, " ").trim();
  }
  function labelMatches(field, text) {
    return LABEL_PATTERNS[field].some((pattern) => pattern.test(text));
  }
  function quotedAttributeValue(value) {
    return String(value).replace(/\\/gu, "\\\\").replace(/"/gu, '\\"');
  }
  function fieldLabels(document, element) {
    const labels = [];
    if (element.labels) labels.push(...element.labels);
    const wrappingLabel = element.closest?.("label");
    if (wrappingLabel) labels.push(wrappingLabel);
    const id = element.getAttribute("id");
    if (id) {
      labels.push(
        ...document.querySelectorAll(`label[for="${quotedAttributeValue(id)}"]`)
      );
    }
    const fieldRow = element.closest(
      ".layui-form-item, .form-group, .form-item, .field, tr"
    );
    if (fieldRow) {
      labels.push(
        ...fieldRow.querySelectorAll(
          ".layui-form-label, .control-label, .form-label, label, th, dt"
        )
      );
    }
    return unique(labels).map(textOf).join(" ");
  }
  function nearestFieldGroup(element) {
    return element.closest("form") ?? element.closest("[data-page], main, section, article") ?? element.ownerDocument?.body;
  }
  function fieldContextText(element) {
    return textOf(
      element.closest(".layui-form-item, .form-group, .form-item, .field, tr") ?? element.parentElement
    );
  }
  function fieldGroupScore(document, element) {
    const group = nearestFieldGroup(element);
    if (!group) return 0;
    let score = 0;
    for (const field of FIELDS) {
      const controls = [
        ...group.querySelectorAll(CONTROL_SELECTOR)
      ].filter((control) => labelMatches(field, fieldLabels(document, control)));
      if (controls.length > 0) score += 10;
    }
    return score;
  }
  function fieldScore(document, field, element) {
    const labelText = fieldLabels(document, element);
    const contextText = fieldContextText(element);
    const placeholder = element.getAttribute("placeholder") ?? "";
    const ariaLabel = element.getAttribute("aria-label") ?? "";
    const name = element.getAttribute("name") ?? "";
    const id = element.getAttribute("id") ?? "";
    let score = fieldGroupScore(document, element);
    if (labelMatches(field, labelText)) score += 100;
    if (labelMatches(field, contextText)) score += 40;
    if (labelMatches(field, `${placeholder} ${ariaLabel}`)) score += 20;
    if (labelMatches(field, `${name} ${id}`)) score += 5;
    if (element.closest("form")) score += 1;
    if (QUERY_CONTEXT_PATTERN.test(contextText)) score -= 100;
    return score;
  }
  function selectBestField(document, field, candidates) {
    const scored = unique(candidates).filter(isVisible).map((element, index) => ({
      element,
      index,
      score: fieldScore(document, field, element)
    })).sort((a, b) => b.score - a.score || a.index - b.index);
    if (scored.length === 0) return null;
    if (scored.length === 1 || scored[0].score > scored[1].score) {
      return scored[0].element;
    }
    throw new Error(`AMBIGUOUS_FIELD:${field}`);
  }
  function labelControl(document, label) {
    if (label.control) return label.control;
    const forID = label.getAttribute("for");
    if (forID) return document.getElementById(forID);
    const nestedControl = label.querySelector(CONTROL_SELECTOR);
    if (nestedControl) return nestedControl;
    return label.closest(".layui-form-item, .form-group, .form-item, .field, tr")?.querySelector(CONTROL_SELECTOR);
  }
  function labelCandidates(document, field) {
    const controls = [];
    for (const label of [...document.querySelectorAll("label")].filter(isVisible)) {
      if (labelMatches(field, textOf(label))) {
        const control = labelControl(document, label);
        if (control && isVisible(control)) controls.push(control);
      }
    }
    return controls;
  }
  function resolveFieldByLabel(document, field) {
    return selectBestField(document, field, labelCandidates(document, field));
  }
  function resolveField(document, field) {
    const candidates = [];
    for (const selector of FIELD_SELECTORS[field]) {
      candidates.push(...document.querySelectorAll(selector));
    }
    candidates.push(...labelCandidates(document, field));
    return selectBestField(document, field, candidates);
  }
  function resolveQueryButton(document) {
    for (const selector of QUERY_SELECTORS) {
      let matches = [...document.querySelectorAll(selector)].filter(isVisible);
      if (selector.includes("button") || selector.includes("role")) {
        matches = matches.filter((button) => {
          const text = textOf(button);
          return /查询|检索|搜索|获取|智能提取|提取文献/u.test(text) && !/发布|提交|求助$/u.test(text);
        });
      }
      if (matches.length > 1) throw new Error("AMBIGUOUS_DOI_QUERY_CONTROL");
      if (matches.length === 1) return matches[0];
    }
    throw new Error("DOI_QUERY_CONTROL_NOT_FOUND");
  }
  function visibleQueryError(document) {
    for (const selector of QUERY_ERROR_SELECTORS) {
      const match = [...document.querySelectorAll(selector)].find(
        (element) => isVisible(element) && element.textContent.trim()
      );
      if (match) return match.textContent.trim();
    }
    return "";
  }
  function resolveQueryInput(document) {
    const candidates = [
      ...document.querySelectorAll(
        [
          '[data-testid="doi-query-input"]',
          'input[name="doi-query"]',
          'input[placeholder*="PMID" i]',
          'input[placeholder*="DOI" i]'
        ].join(",")
      )
    ].filter(isVisible);
    const preferred = candidates.filter(
      (element) => QUERY_CONTEXT_PATTERN.test(`${fieldContextText(element)} ${element.placeholder ?? ""}`)
    );
    if (preferred.length === 1) return preferred[0];
    if (preferred.length > 1) throw new Error("AMBIGUOUS_DOI_QUERY_FIELD");
    return resolveField(document, "doi");
  }
  function setNativeValue(element, value) {
    if (element.isContentEditable) {
      element.textContent = value;
      return;
    }
    const prototype = Object.getPrototypeOf(element);
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (setter) setter.call(element, value);
    else element.value = value;
  }
  function getNativeValue(element) {
    return element?.isContentEditable ? element.textContent : element?.value ?? "";
  }
  function writeValue(document, element, value) {
    setNativeValue(element, value);
    const Event = document.defaultView?.Event ?? globalThis.Event;
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function formValue(field, value) {
    if (field === "authors" && Array.isArray(value)) return value.join("\uFF1B");
    return String(value ?? "");
  }
  function supplementalInfo(values) {
    const lines = [];
    const authors = formValue("authors", values.authors);
    const publicationTitle = formValue(
      "publicationTitle",
      values.publicationTitle
    );
    const year = formValue("year", values.year);
    if (authors.trim()) lines.push(`\u4F5C\u8005\uFF1A${authors}`);
    if (publicationTitle.trim()) lines.push(`\u671F\u520A\uFF1A${publicationTitle}`);
    if (year.trim()) lines.push(`\u5E74\u4EFD\uFF1A${year}`);
    return lines.join("\n");
  }
  function createAbleSciAdapter(document) {
    function readValues() {
      return Object.fromEntries(
        FIELDS.map((field) => {
          const element = resolveField(document, field);
          return [field, getNativeValue(element)];
        })
      );
    }
    function writeEmptyFields(values) {
      for (const field of FIELDS) {
        const element = resolveField(document, field);
        const nextValue = formValue(field, values[field]);
        if (element && !getNativeValue(element).trim() && nextValue.trim()) {
          writeValue(document, element, nextValue);
        }
      }
      const otherInfo = resolveFieldByLabel(document, "otherInfo");
      const otherValue = supplementalInfo(values);
      if (otherInfo && !getNativeValue(otherInfo).trim() && otherValue.trim()) {
        writeValue(document, otherInfo, otherValue);
      }
    }
    async function queryDoi(doi, { timeoutMs = 1e4, pollMs = 50 } = {}) {
      const doiInput = resolveQueryInput(document);
      if (!doiInput) throw new Error("FIELD_NOT_FOUND:doi");
      const queryButton = resolveQueryButton(document);
      const before = JSON.stringify({ ...readValues(), doi: "" });
      writeValue(document, doiInput, doi);
      await new Promise((resolve, reject) => {
        let settled = false;
        let observer;
        let interval;
        let timeout;
        const finish = (callback, value) => {
          if (settled) return;
          settled = true;
          clearTimeout(timeout);
          clearInterval(interval);
          observer?.disconnect();
          callback(value);
        };
        const check = () => {
          if (settled) return;
          try {
            if (visibleQueryError(document)) {
              finish(reject, new Error("DOI_QUERY_FAILED"));
              return;
            }
            const after = JSON.stringify({ ...readValues(), doi: "" });
            if (after !== before) finish(resolve);
          } catch (error) {
            finish(reject, error);
          }
        };
        observer = new MutationObserver(check);
        observer.observe(document.documentElement, {
          attributes: true,
          childList: true,
          characterData: true,
          subtree: true
        });
        interval = setInterval(check, pollMs);
        timeout = setTimeout(
          () => finish(reject, new Error("DOI_QUERY_TIMEOUT")),
          timeoutMs
        );
        try {
          queryButton.click();
          check();
        } catch (error) {
          finish(reject, error);
        }
      });
    }
    return {
      isLoginPage: () => Boolean(document.querySelector('input[type="password"]')),
      isCreatePage: () => Boolean(resolveField(document, "doi") || resolveField(document, "title")),
      readValues,
      writeEmptyFields,
      queryDoi
    };
  }

  // src/browser/session-client.js
  function createSessionClient(sendMessage = (message) => globalThis.chrome.runtime.sendMessage(message)) {
    async function request(message) {
      try {
        const response = await sendMessage(message);
        if (!response?.ok) throw new Error("SESSION_STORE_FAILED");
        return response.value;
      } catch {
        throw new Error("SESSION_STORE_FAILED");
      }
    }
    return {
      save: (task) => request({ type: "ABLESCI_TASK_SAVE", task }),
      load: () => request({ type: "ABLESCI_TASK_LOAD" }),
      clear: () => request({ type: "ABLESCI_TASK_CLEAR" })
    };
  }

  // src/browser/status-panel.js
  var FIELD_LABELS = Object.freeze({
    title: "\u6807\u9898",
    doi: "DOI",
    authors: "\u4F5C\u8005",
    publicationTitle: "\u671F\u520A",
    year: "\u5E74\u4EFD",
    url: "\u5B98\u7F51\u94FE\u63A5"
  });
  function displayValue(value) {
    return Array.isArray(value) ? value.join("\uFF1B") : String(value ?? "");
  }
  function createStatusPanel(document, { copy, cancel, fallbackText = "" }) {
    document.getElementById("zotero-ablesci-status")?.remove();
    const root = document.createElement("aside");
    root.id = "zotero-ablesci-status";
    root.setAttribute("role", "status");
    root.setAttribute("aria-live", "polite");
    root.innerHTML = `
    <div class="zotero-ablesci-heading">Zotero \u79D1\u7814\u901A\u52A9\u624B</div>
    <div class="zotero-ablesci-message"></div>
    <ul class="zotero-ablesci-conflicts"></ul>
    <div class="zotero-ablesci-fallback"></div>
    <div class="zotero-ablesci-actions">
      <button type="button" data-action="copy">\u590D\u5236\u5168\u90E8\u5143\u6570\u636E</button>
      <button type="button" data-action="cancel">\u53D6\u6D88\u672C\u6B21\u586B\u5145</button>
    </div>`;
    document.body.append(root);
    const message = root.querySelector(".zotero-ablesci-message");
    const conflictList = root.querySelector(".zotero-ablesci-conflicts");
    const fallback = root.querySelector(".zotero-ablesci-fallback");
    function show(level, text, conflicts = []) {
      root.dataset.level = level;
      message.textContent = text;
      conflictList.replaceChildren();
      for (const conflict of conflicts) {
        const item = document.createElement("li");
        const label = FIELD_LABELS[conflict.field] ?? conflict.field;
        item.textContent = `${label}\u5B58\u5728\u5DEE\u5F02\uFF1A\u79D1\u7814\u901A\u201C${displayValue(
          conflict.site
        )}\u201D\uFF1BZotero\u201C${displayValue(conflict.zotero)}\u201D`;
        conflictList.append(item);
      }
    }
    root.querySelector('[data-action="copy"]').addEventListener("click", async () => {
      try {
        await copy();
        show("success", "\u5143\u6570\u636E\u5DF2\u590D\u5236");
      } catch {
        show("warning", "\u65E0\u6CD5\u81EA\u52A8\u5199\u5165\u526A\u8D34\u677F\uFF0C\u8BF7\u624B\u52A8\u590D\u5236\u4E0B\u65B9\u5143\u6570\u636E");
        fallback.replaceChildren();
        const textarea = document.createElement("textarea");
        textarea.readOnly = true;
        textarea.value = fallbackText;
        textarea.setAttribute("aria-label", "\u5F85\u590D\u5236\u7684\u6587\u732E\u5143\u6570\u636E");
        fallback.append(textarea);
      }
    });
    root.querySelector('[data-action="cancel"]').addEventListener("click", () => {
      void cancel();
    });
    return {
      root,
      showReading: () => show("info", "\u6B63\u5728\u8BFB\u53D6 Zotero \u5143\u6570\u636E"),
      showLoginRequired: () => show("warning", "\u8BF7\u5148\u767B\u5F55\u79D1\u7814\u901A\uFF0C\u767B\u5F55\u540E\u5C06\u7EE7\u7EED\u81EA\u52A8\u586B\u5199"),
      showQuerying: () => show("info", "\u6B63\u5728\u901A\u8FC7 DOI \u67E5\u8BE2"),
      showReady: (conflicts = [], warning = "") => show(
        warning ? "warning" : "success",
        warning ? `\u5DF2\u81EA\u52A8\u586B\u5145\uFF0C\u8BF7\u6838\u5BF9\u540E\u53D1\u5E03\uFF1B${warning}` : "\u5DF2\u81EA\u52A8\u586B\u5145\uFF0C\u8BF7\u6838\u5BF9\u540E\u53D1\u5E03",
        conflicts
      ),
      showWarning: (text) => show("warning", text),
      showError: (text) => show("error", text),
      destroy: () => root.remove()
    };
  }

  // src/shared/merge.js
  var FIELDS2 = [
    "title",
    "doi",
    "authors",
    "publicationTitle",
    "year",
    "url"
  ];
  function comparable(field, value) {
    const text = Array.isArray(value) ? value.join("; ") : String(value ?? "");
    const normalized = text.trim().replace(/\s+/gu, " ");
    return field === "doi" ? normalized.toLowerCase() : normalized;
  }
  function mergeFormValues(siteValues = {}, zoteroValues = {}) {
    const values = {};
    const conflicts = [];
    for (const field of FIELDS2) {
      const site = siteValues[field] ?? "";
      const zotero = zoteroValues[field] ?? "";
      const comparableSite = comparable(field, site);
      const comparableZotero = comparable(field, zotero);
      values[field] = comparableSite ? site : zotero;
      if (comparableSite && comparableZotero && comparableSite !== comparableZotero) {
        conflicts.push({ field, site, zotero });
      }
    }
    return { values, conflicts };
  }

  // src/browser/workflow.js
  var PAGE_CHANGED_MESSAGE = "\u79D1\u7814\u901A\u9875\u9762\u7ED3\u6784\u5DF2\u53D8\u5316\uFF0C\u65E0\u6CD5\u5B89\u5168\u81EA\u52A8\u586B\u5199";
  function defaultNavigateToCreate() {
    const target = new URL("/assist/create", globalThis.location.origin);
    if (target.origin !== globalThis.location.origin) {
      throw new Error("CROSS_ORIGIN_NAVIGATION_BLOCKED");
    }
    globalThis.location.href = target.href;
  }
  function isExpectedQueryFailure(error) {
    return [
      "DOI_QUERY_FAILED",
      "DOI_QUERY_TIMEOUT",
      "DOI_QUERY_CONTROL_NOT_FOUND",
      "AMBIGUOUS_DOI_QUERY_CONTROL",
      "FIELD_NOT_FOUND:doi"
    ].includes(error?.message);
  }
  function queryFailureMessage(error) {
    if (error?.message === "DOI_QUERY_CONTROL_NOT_FOUND") {
      return "\u672A\u627E\u5230 DOI \u67E5\u8BE2\u6309\u94AE\uFF0C\u5DF2\u6539\u7528 Zotero \u5143\u6570\u636E\u586B\u5145";
    }
    if (error?.message === "FIELD_NOT_FOUND:doi") {
      return "\u672A\u627E\u5230 DOI \u5B57\u6BB5\uFF0C\u5DF2\u6539\u7528 Zotero \u5143\u6570\u636E\u586B\u5145";
    }
    return "DOI \u67E5\u8BE2\u5931\u8D25\uFF0C\u5DF2\u6539\u7528 Zotero \u5143\u6570\u636E\u586B\u5145";
  }
  function pageChangedMessage(error) {
    return `${PAGE_CHANGED_MESSAGE}\uFF1A${error?.message ?? "\u672A\u77E5\u9519\u8BEF"}\uFF1B\u8BF7\u590D\u5236\u5143\u6570\u636E\u540E\u624B\u52A8\u586B\u5199`;
  }
  async function runWorkflow({
    task,
    store,
    panel,
    adapter,
    navigateToCreate = defaultNavigateToCreate,
    now = () => Date.now()
  }) {
    try {
      if (Number.isFinite(task?.createdAt) && now() - task.createdAt > PAYLOAD_TTL_MS) {
        await store.clear();
        panel.showError("\u672C\u6B21 Zotero \u6587\u732E\u4EFB\u52A1\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u8FD4\u56DE Zotero \u91CD\u65B0\u53D1\u8D77");
        return;
      }
      if (adapter.isLoginPage()) {
        await store.save(task);
        panel.showLoginRequired();
        return;
      }
      if (!adapter.isCreatePage()) {
        await store.save(task);
        navigateToCreate();
        return;
      }
      if (task.item.doi) {
        panel.showQuerying();
        try {
          await adapter.queryDoi(task.item.doi, { timeoutMs: 1e4 });
        } catch (error) {
          if (!isExpectedQueryFailure(error)) throw error;
          panel.showWarning(queryFailureMessage(error));
        }
      }
      const { values, conflicts } = mergeFormValues(
        adapter.readValues(),
        task.item
      );
      adapter.writeEmptyFields(values);
      await store.clear();
      const warning = !task.item.doi && !task.item.url ? "\u8BF7\u91CD\u70B9\u6838\u5BF9\u5E76\u8865\u5145\u5B98\u7F51\u94FE\u63A5" : "";
      panel.showReady(conflicts, warning);
    } catch (error) {
      panel.showError(pageChangedMessage(error));
    }
  }

  // src/browser/content.js
  function createPanel(document, store, item) {
    const fallbackText = item ? formatMetadataText(item) : "";
    let panel;
    panel = createStatusPanel(document, {
      fallbackText,
      copy: () => globalThis.navigator.clipboard.writeText(fallbackText),
      cancel: async () => {
        await store.clear();
        panel.destroy();
      }
    });
    return panel;
  }
  async function startContentScript({
    document = globalThis.document,
    store = createSessionClient()
  } = {}) {
    let task;
    try {
      task = consumeFragment();
      if (task) await store.save(task);
      else task = await store.load();
    } catch {
      const panel2 = createPanel(document, store, null);
      panel2.showError("Zotero \u5143\u6570\u636E\u65E0\u6548\u6216\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u8FD4\u56DE Zotero \u91CD\u65B0\u53D1\u8D77");
      return;
    }
    if (!task?.item) return;
    const panel = createPanel(document, store, task.item);
    panel.showReading();
    await runWorkflow({
      task,
      store,
      panel,
      adapter: createAbleSciAdapter(document)
    });
  }
  if (globalThis.chrome?.runtime?.sendMessage && globalThis.document) {
    void startContentScript();
  }
})();
